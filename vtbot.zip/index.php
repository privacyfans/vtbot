<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VT-BOT</title>
</head>
<body>
    <h2>VT-BOT</h2>
    <form action="form.php" method="post" target="_blank">
   
        <label for="username">Username:</label><br>
        <select name="username" id="username">
        <option value="Iswarotun">Iswarotun</option>
        <option value="andri.tz">andri.tz</option>
        <option value="dani.k">dani.k</option>
        <option value="ngudi">ngudi</option>
        <option value="indra.n">indra.n</option>
        <option value="lufty.a">lufty.a</option>
        <option value="m.yusup">m.yusup</option>
        <option value="rizki.suwanta">rizki.suwanta</option>
        <option value="soleh">soleh</option>
        <option value="Ani.meilani">Ani.meilani</option>
        <option value="Silvia.n">Silvia.n</option>
        <option value="dian.sya">dian.sya</option>
        <option value="kiki.n">kiki.n</option>
        <option value="C.iman">C.iman</option>
        <option value="andi.wg">andi.wg</option>
        <option value="haldy.fazar">haldy.fazar</option>
        </select>
        <input type="submit" value="Run">
    </form>
    
   
</body>
</html>